export class Employee{
    id:number;
    name:string;
    email?:string;
    phoneNumber?:string;
    contactPreference:string;
    gender:string;
    isActive:boolean;
    department:string;
    dateOfBirth:Date;
    photoPath?:string;
}