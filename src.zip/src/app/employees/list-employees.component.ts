import { Component, OnInit } from '@angular/core';
import {Employee} from '../models/employee.model';



@Component({
  selector: 'app-list-employees',
  templateUrl: './list-employees.component.html',
  styleUrls: ['./list-employees.component.css']
})
export class ListEmployeesComponent implements OnInit {
employees:Employee[]=[
 {id:1,
  name:"mike",
  gender:"male",
  email:"mike@gmail.com",
  phoneNumber:"9876544989",
  contactPreference:"email",
  dateOfBirth:new Date('12/12/89'),
  department:"IT",
  isActive:true,
  photoPath:"assets/images/mike.png"},
  {
    id:2,
  name:"mary",
  gender:"female",
  email:"mary@gmail.com",
  phoneNumber:"9512675434",
  contactPreference:"phone",
  dateOfBirth:new Date('11/11/87'),
  department:"HR",
  isActive:true,
  photoPath:"assets/images/mary.jpg"},
      
      {
        id:3,
  name:"jessica",
  gender:"female",
  email:"jessica@gmail.com",
  phoneNumber:"9890078347",
  contactPreference:"email",
  dateOfBirth:new Date('10/9/94'),
  department:"IT",
  isActive:true,
  photoPath:"assets/images/Jessica.jpg"}
      
    ]

  constructor() { }

  ngOnInit() {
  }

}
