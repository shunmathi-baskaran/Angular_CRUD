import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import {BsDatepickerConfig} from 'ngx-bootstrap/datepicker';
import { Department } from '../models/department.model';
import {Employee} from '../models/employee.model';



@Component({
  selector: 'app-create-employees',
  templateUrl: './create-employees.component.html',
  styleUrls: ['./create-employees.component.css']
})
export class CreateEmployeesComponent implements OnInit {

  datePickerConfig:Partial<BsDatepickerConfig>;
  previewPhoto=false;

  employee:Employee={
    id:null,
    name:null,
    email:null,
    phoneNumber:null,
    contactPreference:null,
    gender:null,
    isActive:null,
    department:null,
    dateOfBirth:null,
    photoPath:null
  }
departments:Department[]=[
  {id:1,name:'Help Disk'},
  {id:2,name:'HR'},
  {id:3,name:'IT'},
  {id:4,name:'Payroll'},
  {id:5,name:'Admin'}
];


  constructor() {
    this.datePickerConfig=Object.assign({},{
      containerClass:'theme-red',
      showWeekNumbers:false,
      dateInputFormat:'DD/MM/YYYY'
  });
   }

  ngOnInit() {
  }

  saveEmployee(newEmployee:Employee):void{
    console.log(newEmployee);
      }

      togglePhotoPreview():void{
        this.previewPhoto=!this.previewPhoto;
        
  }
}
